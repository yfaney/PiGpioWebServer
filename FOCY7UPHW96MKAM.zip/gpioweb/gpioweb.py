from flask import Flask, render_template
import datetime
import RPi.GPIO as GPIO
app = Flask(__name__)

GPIO.setup(7, GPIO.OUT)
GPIO.setup(11, GPIO.OUT)
GPIO.setup(12, GPIO.OUT)
GPIO.setup(13, GPIO.OUT)
GPIO.setup(15, GPIO.OUT)
GPIO.setup(16, GPIO.OUT)
GPIO.setup(18, GPIO.OUT)
GPIO.setup(22, GPIO.OUT)
GPIO.output(7, False)
GPIO.output(11, False)
GPIO.output(12, False)
GPIO.output(13, False)
GPIO.output(15, False)
GPIO.output(16, False)
GPIO.output(18, False)
GPIO.output(22, False)

now = datetime.datetime.now()
timeString = now.strftime("%Y-%m-%d %H:%M")

@app.route("/")
def hello():
   templateData = {
      'title' : 'RPi GPIO Control',
      'time': timeString
      }
   return render_template('gpioweb.html', **templateData)

@app.route("/4/on")
def action4on():
    GPIO.output(7, True)
    message = "GPIO 4 was turned on."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)
    
@app.route("/4/off")
def action4off():
    GPIO.output(7, False)
    message = "GPIO 4 was turned off."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/17/on")
def action17on():
    GPIO.output(11, True)
    message = "GPIO 17 was turned on."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/17/off")
def action17off():
    GPIO.output(11, False)
    message = "GPIO 17 was turned off."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/18/on")
def action18on():
    GPIO.output(12, True)
    message = "GPIO 18 was turned on."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/18/off")
def action18off():
    GPIO.output(12, False)
    message = "GPIO 18 was turned off."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/21/on")
def action21on():
    GPIO.output(13, True)
    message = "GPIO 21 was turned on."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/21/off")
def action21off():
    GPIO.output(13, False)
    message = "GPIO 21 was turned off."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/22/on")
def action22on():
    GPIO.output(15, True)
    message = "GPIO 22 was turned on."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/22/off")
def action22off():
    GPIO.output(15, False)
    message = "GPIO 22 was turned off."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/23/on")
def action23on():
    GPIO.output(16, True)
    message = "GPIO 23 was turned on."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/23/off")
def action23off():
    GPIO.output(16, False)
    message = "GPIO 23 was turned off."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/24/on")
def action24on():
    GPIO.output(18, True)
    message = "GPIO 24 was turned on."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/24/off")
def action24off():
    GPIO.output(18, False)
    message = "GPIO 24 was turned off."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/25/on")
def action25on():
    GPIO.output(22, True)
    message = "GPIO 25 was turned on."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/25/off")
def action25off():
    GPIO.output(22, False)
    message = "GPIO 25 was turned off."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/all/on")
def actionallon():
    GPIO.output(7, True)
    GPIO.output(11, True)
    GPIO.output(12, True)
    GPIO.output(13, True)
    GPIO.output(15, True)
    GPIO.output(16, True)
    GPIO.output(18, True)
    GPIO.output(22, True)
    message = "All GPIO pins were turned on."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

@app.route("/all/off")
def actionalloff():
    GPIO.output(7, False)
    GPIO.output(11, False)
    GPIO.output(12, False)
    GPIO.output(13, False)
    GPIO.output(15, False)
    GPIO.output(16, False)
    GPIO.output(18, False)
    GPIO.output(22, False)
    message = "All GPIO pins were turned off."
    templateData = {
        'message' : message,
        'time' : timeString
    }
    return render_template('gpioweb.html', **templateData)

if __name__ == "__main__":
   app.run(host='0.0.0.0', port=80, debug=True)